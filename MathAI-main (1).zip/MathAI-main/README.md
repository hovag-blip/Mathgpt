# MathMind AI — Website + installable app

MathMind AI is a responsive math-only tutor website. It can be installed as a Progressive Web App (PWA) on compatible phones, tablets, and computers. It includes example questions, step-by-step AI tutoring, worksheet-photo upload, and a small offline arithmetic practice mode.

## What works in the preview

- Responsive design for desktop and mobile.
- Arithmetic expressions such as `(3/4) * (2/5)`, parentheses, powers (`^`), and common operators in practice mode.
- A math-only AI endpoint for school math questions, word problems, definitions, and worksheet photos.
- Photo resizing before upload.
- PWA app manifest, icons, and service-worker caching for the app shell.
- Basic request limiting and server-side API-key handling.

The full AI tutoring features need an OpenAI API key and a running Node.js server. The key is intentionally not included. API usage may cost money depending on the API account and usage.

## Run it on your computer

1. Install a current version of Node.js (LTS).
2. Open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to a new file named `.env`.
5. Open `.env` and paste your API key after `OPENAI_API_KEY=`. Keep this file private; never publish it or put it inside the `public` folder.
6. Run `npm start`.
7. Open `http://localhost:3000` in your browser.

Without the API key, the site still loads and its arithmetic practice mode works. Other kinds of math problems require the AI connection.

### Windows quick setup

In PowerShell, from this folder:

```powershell
Copy-Item .env.example .env
npm install
npm start
```

Then edit `.env` in Notepad and add your API key. Restart `npm start` after editing it.

## Owner account setup (not active until the server is configured)

The preferred Owner username is `HovigOwnersecreat`. It is saved in `.env.example` as `OWNER_USERNAME`, but this does **not** create or activate an Owner account by itself. The server must be deployed and configured first.

1. Copy `.env.example` to `.env` for local setup, or enter the values in your hosting provider's private environment-variable settings for deployment.
2. Set `OWNER_SETUP_KEY` to a long, unique private value. Do not send it in email or share it with anyone.
3. Set `SESSION_SECRET` to a different long, random private value.
4. Start/deploy the server with these values.
5. Open the live website and choose **Create a username**. Enter `HovigOwnersecreat`, choose a private password, confirm it, and enter the private `OWNER_SETUP_KEY` in **Site owner setup**. This can create the one Owner account only when the matching server values are configured and no Owner already exists.
6. Sign in with that username and the password you just chose. Open **Account → Owner dashboard**.

Do not send your password or `OWNER_SETUP_KEY` to ChatGPT or anyone else. Never share the `.env` file.

## Forgot-password email setup (required before real emails can be sent)

The **Forgot password?** link is connected to the server. It accepts a username or email, creates a one-use reset token, stores only a hash of that token, and emails a reset link that expires after 30 minutes. The app deliberately shows the same response whether or not an account exists.

Email delivery still needs a real SMTP account. For Gmail, use a Google **App Password** (not your normal Gmail password):

1. Sign in to the Google account that will send MathMind AI emails and turn on 2-Step Verification.
2. In that Google account's security settings, create an App Password if Google makes the option available. Keep it private.
3. Copy `.env.example` to `.env` if you have not already done so. Open `.env` locally and set these values (do not paste secrets into ChatGPT or publish them):

```dotenv
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=kazandjian.hovig2015@gmail.com
SMTP_PASS=put-your-GOOGLE-APP-PASSWORD-here
SMTP_FROM="MathMind AI <kazandjian.hovig2015@gmail.com>"
OWNER_NOTIFICATION_EMAIL=kazandjian.hovig2015@gmail.com
APP_BASE_URL=https://YOUR-REAL-HTTPS-DOMAIN
```

4. Replace `APP_BASE_URL` with the exact HTTPS address where MathMind AI is deployed. Do not leave the example domain. The address must open the website.
5. Restart the server after changing `.env`.
6. Test email delivery from the project folder with `npm run email:test`. It sends a test email to `OWNER_NOTIFICATION_EMAIL` (or `SMTP_USER` if that setting is blank). Check Inbox and Spam/Junk.
7. Open the website, create a test account using an email address you can access, log out, choose **Forgot password?**, enter that username or email, and follow the email link within 30 minutes. Set a new password and log in again.

If the test fails, check the SMTP host/port, sender address, App Password, and whether your provider allows SMTP. Keep `.env` private. **This chat cannot activate your email provider or send real mail until you configure those private credentials and deploy the server.**

## Owner signup notifications

The private Owner dashboard lists usernames, roles, plans, and account creation dates. New-account email notifications are addressed to `kazandjian.hovig2015@gmail.com`; the destination is configured in `.env.example`. To actually send email, set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, and `SMTP_FROM` in your hosting provider's secret/environment settings using credentials from your email provider. Until SMTP is configured, account creation is still recorded for the Owner dashboard and a username-only event is logged by the server. No passwords are emailed, logged, stored in plain text, or shown in the dashboard.

For production, replace the starter JSON file with a managed database and persistent storage, configure a strong `SESSION_SECRET`, use HTTPS, and configure backups and rate limiting.

## Prepare Android and iOS builds

This project includes a Capacitor configuration as a starting point for native mobile packaging. First deploy MathMind AI to an HTTPS domain and keep the API server online; mobile apps must connect to the deployed server rather than relying on a local development server. Then install dependencies and initialize the native projects:

```bash
npm install
npx cap add android
npx cap add ios
npx cap sync
npx cap open android
# On macOS with Xcode installed:
npx cap open ios
```

**Before building native apps:** configure a production API base URL in the client (the current web client uses same-origin `/api` routes), test login/session cookies on the deployed domain, and ensure authentication/session handling works in the native WebView. The iOS build requires macOS and Xcode. Android release builds require Android Studio and signing.

**Google Play release checklist:** create a Play Console developer account, provide app listing/screenshots/privacy policy/data-safety details, generate a signed Android App Bundle (`.aab`), complete testing, and submit for review.

**Apple App Store release checklist:** enroll in the Apple Developer Program, build/sign/archive in Xcode, provide screenshots/privacy details and required account-deletion support if accounts can be created, test with TestFlight, and submit for review. Store approval is not guaranteed.

Premium plans currently display sample prices only; real subscriptions must be implemented using platform-compliant billing before selling memberships inside native apps. Owner access remains creator-only and must never be sold.

## Publish it as a website

The project needs a Node.js-capable hosting service because the AI key must stay on the server. Upload the whole project (excluding `.env`) to a trusted Node.js host, configure these environment variables in that host's private settings, and deploy:

- `OPENAI_API_KEY` — your private API key
- `OPENAI_MODEL` — optional; defaults to `gpt-4.1-mini`
- `PORT` — usually supplied by the host automatically

Use the host's HTTPS address to test the website. The PWA install feature requires HTTPS when deployed (localhost is also allowed for testing). Connect a custom domain later through the host's domain settings.

**Never publish `.env`, place your API key in frontend JavaScript, or share screenshots of the key.** Have a trusted adult help with any account or billing setup if needed.


## Publish the website with Render (starter deployment)

This repository includes `render.yaml` as a deployment starting point. In Render, choose **New → Blueprint**, connect the GitHub repository, and let Render read `render.yaml`. The configuration uses a persistent disk for the JSON account file; the selected Starter service/disk may incur charges. Do not use an ephemeral filesystem for real accounts.

Before deployment completes, fill the private environment values in Render:

- `OPENAI_API_KEY`: your API key, if you want AI answers enabled.
- `OWNER_SETUP_KEY`: a new, long, unique secret only you keep.
- `SMTP_PASS`: a Google App Password for the sender account (not its normal password).
- `APP_BASE_URL`: the exact HTTPS Render URL after the service is created. If you change this after first deploy, save the setting and redeploy.

Keep all secrets in Render's Environment settings, never in GitHub. After deployment, open `/api/health` on the live site. Check `emailConfigured` and `passwordResetConfigured`; both should be `true` before you expect real reset emails. Then use **Forgot password?** on a test account and check Inbox/Spam. Do not treat the generic confirmation on the page as proof an email was delivered.

Create the Owner account only after the service and private `OWNER_SETUP_KEY` are configured. Use the username `HovigOwnersecreat`, enter your own strong password, and provide the Owner setup key in the signup form. Do not share that password or key.

## Important limits

- The math-only role is enforced with model instructions, but no language-model prompt can guarantee perfect classification in every edge case.
- Offline practice mode only evaluates typed arithmetic expressions. AI explanations, word problems, and image solving require the server and API key.
- The included in-memory rate limiter is suitable for a starter project; a larger public service should use a production rate-limit store and monitoring.
- The app shell can be cached for offline opening, but AI requests require an internet connection.
