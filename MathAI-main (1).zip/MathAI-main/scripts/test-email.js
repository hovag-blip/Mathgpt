import 'dotenv/config';
import nodemailer from 'nodemailer';

const required = ['SMTP_HOST', 'SMTP_USER', 'SMTP_PASS', 'SMTP_FROM'];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Email is not configured. Fill these private environment variables first: ${missing.join(', ')}`);
  process.exit(1);
}
const to = process.env.EMAIL_TEST_TO || process.env.OWNER_NOTIFICATION_EMAIL || process.env.SMTP_USER;
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: process.env.SMTP_SECURE === 'true',
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});
try {
  await transporter.verify();
  await transporter.sendMail({
    from: process.env.SMTP_FROM,
    to,
    subject: 'MathMind AI email setup test',
    text: 'This is a test email from MathMind AI. If you received it, the configured SMTP service can send mail. No passwords or account secrets are included.',
  });
  console.log(`Test email sent to ${to}. Check Inbox and Spam/Junk folders.`);
} catch (error) {
  console.error('Email test failed. Check your SMTP host, port, sender, and provider-issued app password.');
  console.error(error?.message || 'Unknown SMTP error');
  process.exit(1);
}
