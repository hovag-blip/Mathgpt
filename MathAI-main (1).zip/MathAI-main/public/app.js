(() => {
  const $ = (s) => document.querySelector(s);
  const welcomePanel = $('#welcomePanel');
  const chatFeed = $('#chatFeed');
  const input = $('#questionInput');
  const sendBtn = $('#sendBtn');
  const imageInput = $('#imageInput');
  const attachmentPreview = $('#attachmentPreview');
  const previewImage = $('#previewImage');
  const previewName = $('#previewName');
  const installBtn = $('#installBtn');
  const toast = $('#toast');
  const connectionLabel = $('#connectionLabel');
  const engineNote = $('#engineNote');
  let attachedImage = null;
  let installPrompt = null;
  let toastTimer = null;
  let apiChecked = false;
  let aiAvailable = false;

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2700);
  }

  async function checkApi() {
    try {
      const r = await fetch('/api/health', { cache: 'no-store' });
      if (!r.ok) throw new Error('not connected');
      const data = await r.json();
      aiAvailable = !!data.aiEnabled;
      connectionLabel.textContent = aiAvailable ? 'AI tutor connected' : 'Practice mode available';
      engineNote.textContent = aiAvailable ? 'AI tutor connected' : 'Practice mode works without setup';
      apiChecked = true;
    } catch (_) {
      aiAvailable = false;
      connectionLabel.textContent = 'Practice mode available';
      engineNote.textContent = 'Offline practice mode';
      apiChecked = true;
    }
  }

  function revealChat() {
    welcomePanel.hidden = true;
    chatFeed.hidden = false;
    chatFeed.style.display = 'flex';
  }

  function resetChat() {
    chatFeed.innerHTML = '';
    chatFeed.hidden = true;
    chatFeed.style.display = '';
    welcomePanel.hidden = false;
    input.value = '';
    input.style.height = 'auto';
    clearAttachment();
    input.focus();
  }

  function escapeText(value) {
    return String(value).replace(/[&<>"']/g, (ch) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }

  function addMessage({ role, text, imageUrl = null, typing = false }) {
    revealChat();
    const row = document.createElement('article');
    row.className = `chat-message ${role === 'user' ? 'user' : 'assistant'}`;
    const avatar = role === 'user' ? '●' : '∑';
    const title = role === 'user' ? 'YOU' : 'MATHMIND AI';
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    let content = '';
    if (typing) {
      content = '<div class="message-text typing-dots" aria-label="Solving"><span></span><span></span><span></span></div>';
    } else {
      content = `<div class="message-text">${escapeText(text || '')}</div>`;
      if (imageUrl) content += `<img class="message-photo" src="${imageUrl}" alt="Attached math question" />`;
    }
    row.innerHTML = `<div class="message-avatar" aria-hidden="true">${avatar}</div><div class="message-body"><div class="message-name">${title}<span class="message-time">${timestamp}</span></div>${content}</div>`;
    chatFeed.appendChild(row);
    chatFeed.scrollTop = chatFeed.scrollHeight;
    return row;
  }

  function clearAttachment() {
    attachedImage = null;
    imageInput.value = '';
    attachmentPreview.hidden = true;
    previewImage.removeAttribute('src');
    $('#composer').classList.remove('has-attachment');
  }

  async function shrinkImage(file) {
    if (!file || !/^image\/(png|jpeg|webp)$/.test(file.type)) throw new Error('Choose a JPG, PNG, or WEBP image.');
    if (file.size > 12 * 1024 * 1024) throw new Error('That image is very large. Please choose one smaller than 12 MB.');
    const sourceUrl = URL.createObjectURL(file);
    try {
      const image = new Image();
      image.src = sourceUrl;
      await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; });
      const scale = Math.min(1, 1500 / Math.max(image.naturalWidth, image.naturalHeight));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
      const ctx = canvas.getContext('2d');
      ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      return { dataUrl, fileName: file.name || 'math-worksheet.jpg' };
    } finally {
      URL.revokeObjectURL(sourceUrl);
    }
  }

  imageInput.addEventListener('change', async () => {
    const file = imageInput.files && imageInput.files[0];
    if (!file) return;
    try {
      const result = await shrinkImage(file);
      attachedImage = result.dataUrl;
      previewImage.src = result.dataUrl;
      previewName.textContent = result.fileName;
      attachmentPreview.hidden = false;
      $('#composer').classList.add('has-attachment');
      input.focus();
    } catch (error) {
      showToast(error.message || 'Could not open that image.');
      clearAttachment();
    }
  });
  $('#attachBtn').addEventListener('click', () => imageInput.click());
  $('#removeImageBtn').addEventListener('click', clearAttachment);

  function tokenizeExpression(expression) {
    const tokens = expression.match(/(?:\d+\.?\d*|\.\d+)|[()+\-*/%^]/g);
    if (!tokens || tokens.join('').replace(/\s/g, '') !== expression.replace(/\s/g, '')) return null;
    return tokens;
  }

  function evaluateExpression(expression) {
    if (expression.length > 150 || !/^[\d\s.+\-*/^()%×÷]+$/.test(expression)) return null;
    const source = expression.replace(/\s+/g, '').replace(/×/g, '*').replace(/÷/g, '/');
    const tokens = tokenizeExpression(source);
    if (!tokens) return null;
    let i = 0;
    const parseExpression = () => {
      let value = parseTerm();
      while (tokens[i] === '+' || tokens[i] === '-') {
        const op = tokens[i++];
        const next = parseTerm();
        value = op === '+' ? value + next : value - next;
      }
      return value;
    };
    const parseTerm = () => {
      let value = parseUnary();
      while (['*', '/', '%'].includes(tokens[i])) {
        const op = tokens[i++];
        const next = parseUnary();
        if ((op === '/' || op === '%') && next === 0) throw new Error('Cannot divide by zero.');
        value = op === '*' ? value * next : op === '/' ? value / next : value % next;
      }
      return value;
    };
    const parseUnary = () => {
      if (tokens[i] === '+') { i++; return parseUnary(); }
      if (tokens[i] === '-') { i++; return -parseUnary(); }
      return parsePower();
    };
    const parsePower = () => {
      let value;
      if (tokens[i] === '(') {
        i++;
        value = parseExpression();
        if (tokens[i++] !== ')') throw new Error('Check your parentheses.');
      } else {
        const token = tokens[i++];
        if (token === undefined || !/^\d*\.?\d+$/.test(token)) throw new Error('Please check the math expression.');
        value = Number(token);
      }
      if (tokens[i] === '^') { i++; value = Math.pow(value, parseUnary()); }
      return value;
    };
    try {
      const result = parseExpression();
      if (i !== tokens.length || !Number.isFinite(result)) return null;
      return { result, source };
    } catch (error) {
      if (error.message === 'Cannot divide by zero.' || error.message === 'Check your parentheses.') return { error: error.message };
      return null;
    }
  }

  function localMathAnswer(question, hasImage) {
    const text = question.trim();
    if (!text && hasImage) return { text: 'To solve a worksheet photo, connect the AI tutor using the setup guide included with the project. In this preview, you can still type an arithmetic expression such as (3/4) * (2/5).' };
    if (!text) return { text: 'Type a math expression or a math question to get started.' };
    const mathWords = /\b(math|calculate|solve|simplify|fraction|decimal|percent|percentage|equation|algebra|geometry|area|perimeter|multiply|multiplication|divide|division|add|subtract|sum|difference|product|quotient|square root|factor|multiple|prime number|probability|ratio|proportion|x\s*\+|find|how many|how much|equals|equal to|is the value|volume|triangle|rectangle|circle|angle|integer|negative|positive)\b/i;
    const hasNumber = /\d/.test(text);
    const expression = evaluateExpression(text);
    if (expression && expression.error) return { text: expression.error };
    if (expression) {
      const answer = Number.isInteger(expression.result) ? String(expression.result) : String(Number(expression.result.toPrecision(12)));
      return { text: `Practice mode calculation\n\nExpression: ${expression.source}\nAnswer: ${answer}\n\nFor step-by-step explanations, equations, word problems, or worksheet photos, connect the AI tutor with an API key using the included setup guide.` };
    }
    if (hasNumber && mathWords.test(text) && !aiAvailable) {
      return { text: 'This looks like a math question, but the AI tutor is not connected yet. Add an API key using the setup guide to get step-by-step solutions for fractions, equations, geometry, word problems, and worksheet photos.' };
    }
    return { text: 'I can only help with math questions. Please send a math problem, such as “What is 3/4 × 2/5?”\n\nThe full AI tutor must be connected to solve word problems and explain steps. The preview can calculate typed arithmetic expressions.' };
  }

  async function askAI(question, imageData) {
    const payload = { question };
    if (imageData) payload.imageData = imageData;
    const response = await fetch('/api/solve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'The AI tutor could not answer right now.');
    return data.answer;
  }

  async function submitQuestion(presetQuestion = null) {
    const question = (presetQuestion || input.value).trim();
    if (!question && !attachedImage) {
      input.focus();
      showToast('Type a math question first.');
      return;
    }
    const imageData = attachedImage;
    const visibleImage = imageData;
    addMessage({ role: 'user', text: question || 'Please solve the math in this photo.', imageUrl: visibleImage });
    input.value = '';
    input.style.height = 'auto';
    clearAttachment();
    sendBtn.disabled = true;
    sendBtn.innerHTML = '<span>Working</span><svg viewBox="0 0 24 24"><path d="M12 3v3m0 12v3M3 12h3m12 0h3M5.6 5.6l2.1 2.1m8.6 8.6 2.1 2.1m0-12.8-2.1 2.1m-8.6 8.6-2.1 2.1"/></svg>';
    const typing = addMessage({ role: 'assistant', text: '', typing: true });
    try {
      if (!apiChecked) await checkApi();
      if (aiAvailable) {
        const answer = await askAI(question, imageData);
        typing.remove();
        addMessage({ role: 'assistant', text: answer || 'I could not create an answer. Please try rephrasing your math question.' });
      } else {
        await new Promise(resolve => setTimeout(resolve, 350));
        typing.remove();
        const result = localMathAnswer(question, !!imageData);
        addMessage({ role: 'assistant', text: result.text });
      }
    } catch (error) {
      typing.remove();
      const result = localMathAnswer(question, !!imageData);
      if (imageData || !evaluateExpression(question)) {
        addMessage({ role: 'assistant', text: error.message.includes('fetch') ? result.text : `${result.text}\n\nConnection note: ${error.message}` });
      } else {
        addMessage({ role: 'assistant', text: result.text });
      }
      showToast('AI connection unavailable — used practice mode.');
    } finally {
      sendBtn.disabled = false;
      sendBtn.innerHTML = '<span> Solve </span><svg viewBox="0 0 24 24"><path d="M5 12h13m-5-5 5 5-5 5"/></svg>';
      input.focus();
      chatFeed.scrollTop = chatFeed.scrollHeight;
    }
  }

  sendBtn.addEventListener('click', () => submitQuestion());
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = `${Math.min(input.scrollHeight, 170)}px`;
  });
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      submitQuestion();
    }
  });
  $('#newChatBtn').addEventListener('click', resetChat);
  document.querySelectorAll('[data-prompt]').forEach(button => {
    button.addEventListener('click', () => {
      const prompt = button.getAttribute('data-prompt');
      if (welcomePanel.hidden) {
        input.value = prompt;
        input.focus();
        input.style.height = 'auto';
        input.style.height = `${Math.min(input.scrollHeight, 170)}px`;
      } else {
        input.value = prompt;
        submitQuestion(prompt);
      }
      $('#sidebar').classList.remove('open');
    });
  });
  $('#menuBtn').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
  document.addEventListener('click', (event) => {
    if (window.innerWidth <= 720 && $('#sidebar').classList.contains('open') && !$('#sidebar').contains(event.target) && !$('#menuBtn').contains(event.target)) $('#sidebar').classList.remove('open');
  });
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    installPrompt = event;
    installBtn.hidden = false;
  });
  installBtn.addEventListener('click', async () => {
    if (!installPrompt) {
      showToast('On your phone, use your browser menu and choose “Add to Home Screen”.');
      return;
    }
    installPrompt.prompt();
    await installPrompt.userChoice;
    installPrompt = null;
    installBtn.hidden = true;
  });
  window.addEventListener('appinstalled', () => showToast('MathMind AI was installed.'));

  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  }
  checkApi();
})();
