(() => {
  const $ = (selector) => document.querySelector(selector);
  const authScreen = $('#authScreen');
  const authCard = $('#authCard');
  const appShell = document.querySelector('.app-shell');
  let currentUser = null;

  const plans = [
    { id: 'free', name: 'Free', price: '$0', period: 'forever', detail: 'Basic math practice and a limited starter experience.', bullets: ['Arithmetic practice', 'Core math workspace', 'Create an account'], action: 'Current free plan' },
    { id: 'plus', name: 'Plus', price: '$3.99', period: 'per month', detail: 'For students who want more regular math help.', bullets: ['AI step-by-step math help*', 'Worksheet photo questions*', 'All math topics*'], action: 'Request Plus' },
    { id: 'extreme-vip', name: 'Extreme VIP', price: '$8.99', period: 'per month', detail: 'A premium plan for frequent practice.', bullets: ['Everything in Plus*', 'Premium experience*', 'Priority feature access*'], action: 'Request Extreme VIP' },
    { id: 'owner', name: 'Owner', price: 'Invite only', period: 'not for sale', detail: 'Reserved for the site creator. Users cannot buy or select this role.', bullets: ['View account usernames', 'Issue temporary password resets', 'Owner dashboard'], action: 'Only assigned by creator' },
  ];

  async function api(url, options = {}) {
    const response = await fetch(url, {
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      ...options,
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || data.message || 'Something went wrong. Please try again.');
    return data;
  }
  function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  }
  function flash(message, kind = 'info') {
    const box = $('#authNotice');
    if (!box) { window.alert(message); return; }
    box.textContent = message;
    box.className = `auth-notice ${kind}`;
    box.hidden = false;
  }
  function formTemplate({ title, subtitle, eyebrow = 'WELCOME TO MATHMIND AI', content, submitText, footnote = '' }) {
    return `<div class="auth-eyebrow">${esc(eyebrow)}</div><h1>${esc(title)}</h1><p class="auth-subtitle">${esc(subtitle)}</p><div id="authNotice" class="auth-notice" hidden></div><form id="authForm" class="auth-form">${content}<button class="auth-primary" type="submit">${esc(submitText)} <span>→</span></button></form>${footnote}<div class="auth-madeby">Made by: <strong>Hovig Kazandjian</strong></div>`;
  }
  function field(label, name, type = 'text', extra = '') {
    const autocomplete = type === 'password'
      ? (name === 'currentPassword' ? 'current-password' : 'new-password')
      : (name === 'username' ? 'username' : (type === 'email' ? 'email' : 'off'));
    return `<label class="auth-field"><span>${esc(label)}</span><input name="${esc(name)}" type="${esc(type)}" autocomplete="${autocomplete}" ${extra} required /></label>`;
  }
  function showLogin(message = '') {
    authScreen.hidden = false; appShell.hidden = true;
    authCard.innerHTML = formTemplate({
      title: 'Welcome back.', subtitle: 'Sign in with your username and password to open your math workspace.',
      content: `${field('Username', 'username', 'text', 'minlength="3" maxlength="24"')}${field('Password', 'password', 'password', 'maxlength="200"')}<div class="auth-link-row"><button class="text-link" id="forgotLink" type="button">Forgot password?</button></div>`,
      submitText: 'Log in', footnote: `<p class="auth-switch">New to MathMind? <button id="signupLink" class="text-link" type="button">Create a username</button></p>`,
    });
    $('#authForm').addEventListener('submit', async (event) => {
      event.preventDefault(); const form = new FormData(event.currentTarget);
      const submit = event.currentTarget.querySelector('button[type="submit"]'); submit.disabled = true;
      try { const data = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ username: form.get('username'), password: form.get('password') }) }); enterApp(data.user); }
      catch (error) { flash(error.message, 'error'); }
      finally { submit.disabled = false; }
    });
    $('#signupLink').addEventListener('click', showSignup);
    $('#forgotLink').addEventListener('click', showForgot);
    if (message) flash(message, 'info');
  }
  function showSignup() {
    authScreen.hidden = false; appShell.hidden = true;
    authCard.innerHTML = formTemplate({
      title: 'Create your account.', subtitle: 'Choose a username and keep your password private. We never show or send passwords to the site creator.', eyebrow: 'GET STARTED',
      content: `${field('Create a username', 'username', 'text', 'minlength="3" maxlength="24" pattern="[A-Za-z0-9_.-]{3,24}"')}${field('Email address (for password recovery)', 'email', 'email', 'maxlength="254" autocomplete="email"')}${field('Create a password (8+ characters)', 'password', 'password', 'minlength="8" maxlength="200" autocomplete="new-password"')}${field('Confirm password', 'confirmPassword', 'password', 'minlength="8" maxlength="200" autocomplete="new-password"')}<details class="owner-key-details"><summary>Site owner setup</summary><p>Only the creator can use a private setup key configured on the server. Leave this empty for a regular account.</p>${field('Private owner setup key (optional)', 'ownerSetupKey', 'password', 'maxlength="200"')}</details>`,
      submitText: 'Create account', footnote: `<p class="auth-switch">Already have an account? <button id="loginLink" class="text-link" type="button">Log in</button></p>`,
    });
    $('#authForm').addEventListener('submit', async (event) => {
      event.preventDefault(); const form = new FormData(event.currentTarget);
      if (form.get('password') !== form.get('confirmPassword')) return flash('The passwords do not match.', 'error');
      const submit = event.currentTarget.querySelector('button[type="submit"]'); submit.disabled = true;
      try {
        const data = await api('/api/auth/signup', { method: 'POST', body: JSON.stringify({ username: form.get('username'), email: form.get('email'), password: form.get('password'), ownerSetupKey: form.get('ownerSetupKey') || '' }) });
        enterApp(data.user);
      } catch (error) { flash(error.message, 'error'); }
      finally { submit.disabled = false; }
    });
    $('#loginLink').addEventListener('click', () => showLogin());
  }
  function showForgot() {
    authScreen.hidden = false; appShell.hidden = true;
    authCard.innerHTML = formTemplate({
      title: 'Reset your password.', subtitle: 'Enter the username or email address connected to your account. We will email you a secure reset link.', eyebrow: 'ACCOUNT RECOVERY',
      content: `${field('Username or email address', 'identifier', 'text', 'minlength="3" maxlength="254" autocomplete="username"')}<div class="auth-reset-note">The reset link expires after 30 minutes. Check your inbox and spam folder. Your current password is never sent to anyone.</div>`,
      submitText: 'Email reset link', footnote: `<p class="auth-switch"><button id="loginLink" class="text-link" type="button">Back to login</button></p>`,
    });
    $('#authForm').addEventListener('submit', async (event) => {
      event.preventDefault(); const form = new FormData(event.currentTarget);
      const submit = event.currentTarget.querySelector('button[type="submit"]'); submit.disabled = true;
      try { const data = await api('/api/auth/forgot', { method: 'POST', body: JSON.stringify({ identifier: form.get('identifier') }) }); flash(data.message, 'info'); }
      catch (error) { flash(error.message, 'error'); }
      finally { submit.disabled = false; }
    });
    $('#loginLink').addEventListener('click', () => showLogin());
  }
  function showResetPassword(token) {
    authScreen.hidden = false; appShell.hidden = true;
    authCard.innerHTML = formTemplate({
      title: 'Choose a new password.', subtitle: 'Create a new password with at least 8 characters. Reset links can only be used once and expire after 30 minutes.', eyebrow: 'SECURE PASSWORD RESET',
      content: `${field('New password', 'password', 'password', 'minlength="8" maxlength="200" autocomplete="new-password"')}${field('Confirm new password', 'confirmPassword', 'password', 'minlength="8" maxlength="200" autocomplete="new-password"')}`,
      submitText: 'Save new password', footnote: `<p class="auth-switch"><button id="loginLink" class="text-link" type="button">Back to login</button></p>`,
    });
    $('#authForm').addEventListener('submit', async (event) => {
      event.preventDefault(); const form = new FormData(event.currentTarget);
      if (form.get('password') !== form.get('confirmPassword')) return flash('The passwords do not match.', 'error');
      const submit = event.currentTarget.querySelector('button[type="submit"]'); submit.disabled = true;
      try {
        const data = await api('/api/auth/reset-password', { method: 'POST', body: JSON.stringify({ token, password: form.get('password') }) });
        history.replaceState({}, '', location.pathname);
        showLogin(data.message);
      } catch (error) { flash(error.message, 'error'); }
      finally { submit.disabled = false; }
    });
    $('#loginLink').addEventListener('click', () => { history.replaceState({}, '', location.pathname); showLogin(); });
  }
  function enterApp(user) {
    currentUser = user; authScreen.hidden = true; appShell.hidden = false;
    const accountBtn = $('#accountBtn');
    if (accountBtn) accountBtn.innerHTML = `<span class="account-avatar">${esc((user.username || '?').slice(0, 1).toUpperCase())}</span><span>${esc(user.username)}</span>`;
    if (user.mustChangePassword) showChangePassword();
    else showWorkspace();
  }
  function showWorkspace() {
    authScreen.hidden = true; appShell.hidden = false;
    const overlay = $('#accountScreen'); if (overlay) overlay.remove();
  }
  function addAccountOverlay() {
    let overlay = $('#accountScreen');
    if (!overlay) {
      overlay = document.createElement('div'); overlay.id = 'accountScreen'; overlay.className = 'account-screen'; overlay.hidden = true;
      overlay.innerHTML = '<div class="account-panel"><button id="accountClose" class="account-close" type="button" aria-label="Close account panel">×</button><div id="accountContent"></div></div>';
      document.body.appendChild(overlay);
      overlay.addEventListener('click', (event) => { if (event.target === overlay) overlay.hidden = true; });
      $('#accountClose').addEventListener('click', () => { overlay.hidden = true; });
    }
    return overlay;
  }
  function openAccount(section = 'home') {
    const overlay = addAccountOverlay(); overlay.hidden = false;
    const content = $('#accountContent');
    if (section === 'plans') return renderPlans(content);
    if (section === 'owner') return renderOwner(content);
    content.innerHTML = `<div class="account-eyebrow">YOUR ACCOUNT</div><h2>Hello, ${esc(currentUser.username)}.</h2><p class="auth-subtitle">Your MathMind account and plan settings.</p><div class="account-summary"><div><small>USERNAME</small><strong>${esc(currentUser.username)}</strong></div><div><small>ROLE</small><strong>${esc(currentUser.role === 'owner' ? 'Owner' : 'Student')}</strong></div><div><small>PLAN</small><strong>${esc(planName(currentUser.plan))}</strong></div></div><div class="account-actions"><button id="plansBtn" class="auth-primary" type="button">View plans <span>→</span></button>${currentUser.role === 'owner' ? '<button id="ownerBtn" class="auth-secondary" type="button">Owner dashboard</button>' : ''}<button id="changePassBtn" class="auth-secondary" type="button">Change password</button><button id="logoutBtn" class="auth-secondary" type="button">Log out</button><button id="backToMathBtn" class="auth-quiet" type="button">Back to math workspace</button></div><p class="account-security">Your password is never visible to the Owner. The database stores a salted password hash.</p>`;
    $('#plansBtn').addEventListener('click', () => openAccount('plans'));
    if ($('#ownerBtn')) $('#ownerBtn').addEventListener('click', () => openAccount('owner'));
    $('#changePassBtn').addEventListener('click', showChangePassword);
    $('#logoutBtn').addEventListener('click', logout);
    $('#backToMathBtn').addEventListener('click', () => { overlay.hidden = true; });
  }
  function planName(plan) { return ({ free: 'Free', plus: 'Plus', 'extreme-vip': 'Extreme VIP', owner: 'Owner' })[plan] || 'Free'; }
  function renderPlans(content) {
    content.innerHTML = `<div class="account-eyebrow">MEMBERSHIP</div><h2>Choose your plan.</h2><p class="auth-subtitle">Prices below are sample USD prices. Payments are not connected yet, so no charge will be made here.</p><div class="plan-grid">${plans.map((plan) => `<article class="plan-card ${plan.id === currentUser.plan ? 'active-plan' : ''} ${plan.id === 'extreme-vip' ? 'featured-plan' : ''}"><div class="plan-title-row"><h3>${esc(plan.name)}</h3>${plan.id === currentUser.plan ? '<span class="plan-badge">YOUR PLAN</span>' : ''}</div><div class="plan-price">${esc(plan.price)}${plan.price.startsWith('$') ? `<small> / ${esc(plan.period)}</small>` : `<small>${esc(plan.period)}</small>`}</div><p>${esc(plan.detail)}</p><ul>${plan.bullets.map((bullet) => `<li>${esc(bullet)}</li>`).join('')}</ul>${plan.id === 'free' || plan.id === currentUser.plan || plan.id === 'owner' ? `<button class="auth-secondary plan-button" type="button" disabled>${esc(plan.action)}</button>` : `<button class="auth-primary plan-button" type="button" data-plan="${esc(plan.id)}">${esc(plan.action)}</button>`}</article>`).join('')}</div><p class="plan-footnote">*Premium features will require the AI service and a real subscription system to be configured. Owner access cannot be purchased or self-selected.</p><button class="auth-quiet" id="accountBack" type="button">← Back to account</button>`;
    content.querySelectorAll('[data-plan]').forEach((button) => button.addEventListener('click', async () => {
      button.disabled = true;
      try { const result = await api('/api/account/request-plan', { method: 'POST', body: JSON.stringify({ plan: button.dataset.plan }) }); flashInAccount(result.message); currentUser.upgradeRequest = button.dataset.plan; }
      catch (error) { flashInAccount(error.message, 'error'); }
      finally { button.disabled = false; }
    }));
    $('#accountBack').addEventListener('click', () => openAccount('home'));
  }
  function flashInAccount(message, kind = 'info') {
    const content = $('#accountContent');
    let notice = $('#accountNotice');
    if (!notice) { notice = document.createElement('div'); notice.id = 'accountNotice'; content.prepend(notice); }
    notice.className = `auth-notice ${kind}`; notice.textContent = message; notice.hidden = false;
  }
  async function renderOwner(content) {
    content.innerHTML = '<div class="account-eyebrow">CREATOR CONTROL</div><h2>Owner dashboard.</h2><p class="auth-subtitle">View usernames, roles, plans, and upgrade requests. Passwords are never displayed or sent to you.</p><div id="ownerNotice" class="auth-notice" hidden></div><div id="usersTableWrap" class="users-table-wrap">Loading accounts…</div><button class="auth-quiet" id="ownerBack" type="button">← Back to account</button>';
    $('#ownerBack').addEventListener('click', () => openAccount('home'));
    try {
      const data = await api('/api/owner/users');
      const wrap = $('#usersTableWrap');
      wrap.innerHTML = `<div class="users-table-scroll"><table class="users-table"><thead><tr><th>Username</th><th>Role</th><th>Plan</th><th>Upgrade request</th><th>Actions</th></tr></thead><tbody>${data.users.map((user) => `<tr><td><strong>${esc(user.username)}</strong><small>Joined ${esc(new Date(user.createdAt).toLocaleDateString())}</small></td><td>${esc(user.role === 'owner' ? 'Owner' : 'User')}</td><td>${esc(planName(user.plan))}</td><td>${esc(user.upgradeRequest ? planName(user.upgradeRequest) : '—')}</td><td>${user.role === 'owner' ? '<span class="owner-protected">Protected</span>' : `<button class="reset-user-btn" type="button" data-reset-id="${esc(user.id)}" data-reset-name="${esc(user.username)}">Reset password</button>`}</td></tr>`).join('')}</tbody></table></div>`;
      wrap.querySelectorAll('[data-reset-id]').forEach((button) => button.addEventListener('click', async () => {
        if (!confirm(`Generate a temporary password for ${button.dataset.resetName}? The current password will stop working.`)) return;
        button.disabled = true;
        try {
          const result = await api('/api/owner/reset-password', { method: 'POST', body: JSON.stringify({ userId: button.dataset.resetId }) });
          const notice = $('#ownerNotice');
          notice.className = 'auth-notice info';
          notice.innerHTML = `<strong>Temporary password for ${esc(result.username)} (shown once)</strong><div class="temporary-password">${esc(result.temporaryPassword)}</div><p>${esc(result.message)}</p><button id="copyTempPassword" class="auth-secondary" type="button">Copy temporary password</button>`;
          notice.hidden = false;
          $('#copyTempPassword').addEventListener('click', async () => {
            try { await navigator.clipboard.writeText(result.temporaryPassword); $('#copyTempPassword').textContent = 'Copied'; }
            catch { flashInAccount('Copy was blocked by your browser. Select and copy the temporary password manually.', 'error'); }
          });
        } catch (error) { const notice = $('#ownerNotice'); notice.hidden = false; notice.className = 'auth-notice error'; notice.textContent = error.message; }
        finally { button.disabled = false; }
      }));
    } catch (error) {
      const wrap = $('#usersTableWrap'); wrap.textContent = error.message;
      if (error.message.includes('Owner')) wrap.classList.add('error-text');
    }
  }
  function showChangePassword() {
    authScreen.hidden = false; appShell.hidden = true;
    authCard.innerHTML = formTemplate({
      title: 'Choose a new password.', subtitle: 'Create a new private password before continuing. Use at least 8 characters.', eyebrow: currentUser?.mustChangePassword ? 'TEMPORARY PASSWORD' : 'ACCOUNT SECURITY',
      content: `${field('New password', 'password', 'password', 'minlength="8" maxlength="200"')}${field('Confirm new password', 'confirmPassword', 'password', 'minlength="8" maxlength="200"')}`,
      submitText: 'Save new password', footnote: currentUser?.mustChangePassword ? '' : `<p class="auth-switch"><button id="cancelPasswordChange" class="text-link" type="button">Cancel</button></p>`,
    });
    $('#authForm').addEventListener('submit', async (event) => {
      event.preventDefault(); const form = new FormData(event.currentTarget);
      if (form.get('password') !== form.get('confirmPassword')) return flash('The passwords do not match.', 'error');
      const submit = event.currentTarget.querySelector('button[type="submit"]'); submit.disabled = true;
      try { const data = await api('/api/auth/change-password', { method: 'POST', body: JSON.stringify({ password: form.get('password') }) }); enterApp(data.user); }
      catch (error) { flash(error.message, 'error'); }
      finally { submit.disabled = false; }
    });
    if ($('#cancelPasswordChange')) $('#cancelPasswordChange').addEventListener('click', () => { authScreen.hidden = true; appShell.hidden = false; openAccount('home'); });
  }
  async function logout() {
    try { await api('/api/auth/logout', { method: 'POST', body: '{}' }); } catch {}
    currentUser = null; const overlay = $('#accountScreen'); if (overlay) overlay.remove();
    showLogin('You have been logged out.');
  }

  $('#accountBtn')?.addEventListener('click', () => openAccount('home'));
  const resetTokenFromUrl = new URLSearchParams(location.search).get('resetToken');
  if (resetTokenFromUrl) {
    // Keep the token only in memory after reading it, not in the visible address bar.
    history.replaceState({}, '', location.pathname);
    showResetPassword(resetTokenFromUrl);
  } else {
    (async () => {
      try {
        const data = await api('/api/auth/me');
        if (data.user) enterApp(data.user); else showLogin();
      } catch { showLogin('Please log in to continue.'); }
    })();
  }
})();
